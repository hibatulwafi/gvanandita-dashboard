<header id="appHeader"

x-data="{
    menuToggle: false,
    textColor: '',
    isDark: document.documentElement.classList.contains('dark'),
    init() {
        this.updateBg();
        this.updateColor();
        const observer = new MutationObserver(() => {
            this.updateBg();
            this.updateColor();
        });
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    },
    updateBg() {
        this.isDark = document.documentElement.classList.contains('dark');
        const liteBg = '<?php echo e(config('settings.navbar_bg_lite')); ?>';
        const darkBg = '<?php echo e(config('settings.navbar_bg_dark')); ?>';
        this.$el.style.backgroundColor = this.isDark ? darkBg : liteBg;
    },
    updateColor() {
        this.isDark = document.documentElement.classList.contains('dark');
        this.textColor = this.isDark
            ? '<?php echo e(config('settings.navbar_text_dark')); ?>'
            : '<?php echo e(config('settings.navbar_text_lite')); ?>';
    }
}"
x-init="init()"
    class="sticky top-0 flex w-full border-gray-200 lg:border-b dark:border-gray-800 transition-all duration-300 z-9">
    <div class="flex grow flex-col items-center justify-between lg:flex-row lg:px-6">
        <div
            class="flex w-full items-center justify-between gap-2 border-b border-gray-200 px-3 py-2 sm:gap-4 lg:justify-normal lg:border-b-0 lg:px-0 dark:border-gray-800">
            <button
                :class="sidebarToggle ? 'lg:bg-transparent dark:lg:bg-transparent bg-gray-100 dark:bg-gray-800' : ''"
                class="z-99999 flex h-10 w-10 items-center justify-center rounded-md border-gray-200 text-gray-700 lg:h-11 lg:w-11 dark:border-gray-800 dark:text-gray-300 transition-all duration-300"
                id="sidebar-toggle-button"
                @click.stop="sidebarToggle = !sidebarToggle; localStorage.setItem('sidebarToggle', sidebarToggle);">
                <iconify-icon
                 :icon="sidebarToggle ? 'mdi:menu-close' : 'mdi:menu-open'"
                width="26" height="26" class=""></iconify-icon>
            </button>

            <a href="<?php echo e(route('admin.dashboard')); ?>" class="lg:hidden">
                <img class="dark:hidden w-32" src="/images/logo/app-logo.png" alt="Logo" />
                <img class="hidden dark:block w-32" src="/images/logo/app-logo-dark.png" alt="Logo" />
            </a>
        </div>

        <!-- Adjusted Mobile Menu -->
        <div :class="menuToggle ? 'flex' : 'hidden'"
            class="w-full items-center justify-between gap-4 px-5 py-1 shadow-theme-md lg:flex lg:justify-end lg:px-0 lg:shadow-none">
            <div class="flex items-center gap-1">
                <?php echo $__env->make('backend.layouts.partials.demo-mode-notice', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('backend.layouts.partials.locale-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo ld_apply_filters('dark_mode_toggler_before_button', ''); ?>
                <button id="darkModeToggle"
                    class="hover:text-dark-900 relative flex items-center justify-center rounded-full text-gray-700 transition-colors hover:bg-gray-100 hover:text-gray-800 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white p-2 dark-mode-toggle"
                    @click.prevent="darkMode = !darkMode" @click="menuToggle = true">
                    <iconify-icon icon="lucide:moon" width="24" height="24" class="hidden dark:block"></iconify-icon>
                    <iconify-icon icon="lucide:sun" width="24" height="24" class="dark:hidden"></iconify-icon>
                </button>
                <?php ld_apply_filters('dark_mode_toggler_after_button', '') ?>

                <?php if(env('GITHUB_LINK') ): ?>
                    <a href="<?php echo e(env('GITHUB_LINK')); ?>" target="_blank"
                        class="hover:text-dark-900 relative flex p-2 items-center justify-center rounded-full text-gray-700 transition-colors hover:bg-gray-100 hover:text-gray-800 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white">
                        <iconify-icon icon="lucide:github" width="22" height="22"
                            class=""></iconify-icon>
                    </a>
                <?php endif; ?>
            </div>

            <div class="relative" x-data="{ dropdownOpen: false }" @click.outside="dropdownOpen = false">
                <a class="flex items-center text-gray-700 dark:text-gray-300" href="#"
                    @click.prevent="dropdownOpen = ! dropdownOpen">
                    <span class="mr-3 h-8 w-8 overflow-hidden rounded-full">
                        <img src="<?php echo e(auth()->user()->avatar_url ? auth()->user()->avatar_url : auth()->user()->getGravatarUrl()); ?>" alt="User" />
                    </span>
                </a>

                <!-- Dropdown Start -->
                <div x-show="dropdownOpen"
                    class="absolute right-0 mt-[17px] flex w-[220px] flex-col rounded-md border bg-white dark:bg-gray-700 border-gray-200  p-3 shadow-theme-lg dark:border-gray-800 z-100"
                    style="display: none">
                    <div class="border-b border-gray-200 pb-2 dark:border-gray-800 mb-2">
                        <span class="block font-medium text-gray-700 dark:text-gray-300">
                            <?php echo e(auth()->user()->full_name); ?>

                        </span>
                        <span class="mt-0.5 block text-theme-sm text-gray-700 dark:text-gray-300">
                            <?php echo e(auth()->user()->email); ?>

                        </span>
                    </div>

                    <ul class="flex flex-col gap-1 border-b border-gray-200 pb-2 dark:border-gray-800">
                        <li>
                            <a href="<?php echo e(route('profile.edit')); ?>"
                                class="group flex items-center gap-3 rounded-md px-3 py-2 text-theme-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-800 dark:text-gray-300 dark:hover:bg-white/5 dark:hover:text-gray-300">
                                <iconify-icon icon="lucide:user" width="20" height="20" class="fill-gray-500 group-hover:fill-gray-700 dark:fill-gray-400 dark:group-hover:fill-gray-300"></iconify-icon>
                                <?php echo e(__('Edit profile')); ?>

                            </a>
                        </li>
                    </ul>
                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                            class="group flex items-center gap-3 rounded-md px-3 py-2 text-theme-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-800 dark:text-gray-300 dark:hover:bg-white/5 dark:hover:text-gray-300 mt-2 w-full">
                            <iconify-icon icon="lucide:log-out" width="20" height="20" class="fill-gray-500 group-hover:fill-gray-700 dark:group-hover:fill-gray-300"></iconify-icon>
                            <?php echo e(__('Logout')); ?>

                        </button>
                    </form>

                    <?php if(session()->has('original_user_id')): ?>
                        <?php
                            $originalUser = \App\Models\User::find(session('original_user_id'));
                        ?>
                        <?php if($originalUser): ?>
                            <form method="POST" action="<?php echo e(route('admin.users.switch-back')); ?>" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="group flex items-center gap-3 rounded-md px-3 py-2 text-theme-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-800 dark:text-gray-300 dark:hover:bg-white/5 dark:hover:text-gray-300 mt-1 w-full">
                                    <iconify-icon icon="lucide:arrow-left" width="16" height="16"></iconify-icon>
                                    <?php echo e(__('Switch back to')); ?> <?php echo e($originalUser->full_name); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <!-- Dropdown End -->
            </div>
        </div>
    </div>
</header>
<!-- End Header -->
<?php /**PATH D:\project\gvanandita-dashboard\resources\views/backend/layouts/partials/header.blade.php ENDPATH**/ ?>