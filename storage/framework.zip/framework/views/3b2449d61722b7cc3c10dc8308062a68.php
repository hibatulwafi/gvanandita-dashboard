<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'id' => null,
    'title' => '',
    'description' => '',
    'position' => 'top', // top, bottom, left, right
    'width' => '',
    'arrowAlign' => 'center', // left, center, right
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'id' => null,
    'title' => '',
    'description' => '',
    'position' => 'top', // top, bottom, left, right
    'width' => '',
    'arrowAlign' => 'center', // left, center, right
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$positions = [
    'top' => 'bottom-full mb-2 left-1/2 -translate-x-1/2',
    'bottom' => 'top-full mt-2 left-1/2 -translate-x-1/2',
    'left' => 'right-full mr-2 top-1/2 -translate-y-1/2',
    'right' => 'left-full ml-2 top-1/2 -translate-y-1/2',
];
$positionClass = $positions[$position] ?? $positions['top'];

$arrowAlignClass = [
    'left' => 'left-4',
    'center' => 'left-1/2 -translate-x-1/2',
    'right' => 'right-4',
][$arrowAlign] ?? 'left-1/2 -translate-x-1/2';
?>

<div
    x-data="{
        open: false,
        arrowVisible: false,
        show() {
            this.open = true;
            this.arrowVisible = true;
        },
        hide() {
            this.arrowVisible = false;
            setTimeout(() => { this.open = false }, 120);
        }
    }"
    class="relative <?php echo e(!$width ? 'w-fit' : ''); ?>"
    style="<?php echo e($width ? "width: {$width};" : ''); ?>"
>
    <div
        @mouseenter="show()"
        @mouseleave="hide()"
        @focus="show()"
        @blur="hide()"
        tabindex="0"
        aria-describedby="<?php echo e($id); ?>"
        class="outline-none"
    >
        <?php echo e($slot); ?>

    </div>

    <div
        id="<?php echo e($id); ?>"
        x-show="open"
        x-transition.opacity
        class="<?php echo e($positionClass); ?> absolute z-10 inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-md shadow-xs opacity-0 invisible tooltip dark:bg-gray-700 text-center"
        :class="{ 'opacity-100 visible': open, 'opacity-0 invisible': !open }"
        role="tooltip"
        style="min-width: 150px;"
    >
        <?php if($title): ?>
            <span class="text-sm font-medium text-white"><?php echo e($title); ?></span>
        <?php endif; ?>

        <?php if($description): ?>
            <p class="text-balance text-white/90"><?php echo e($description); ?></p>
        <?php endif; ?>

        <div
            x-show="arrowVisible"
            x-transition.opacity
            class="tooltip-arrow transition-opacity duration-100 absolute <?php echo e($arrowAlignClass); ?>"
            :class="{ 'opacity-100 visible': arrowVisible, 'opacity-0 invisible': !arrowVisible }"
            data-popper-arrow
        ></div>
    </div>
</div>
<?php /**PATH D:\project\gvanandita-dashboard\resources\views/components/tooltip.blade.php ENDPATH**/ ?>