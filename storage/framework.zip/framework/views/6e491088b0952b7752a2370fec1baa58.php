

<?php $__env->startSection('title'); ?>
<?php echo e($breadcrumbs['title']); ?> | <?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('before_vite_build'); ?>
<script>
    var userGrowthData = <?php echo json_encode($user_growth_data['data'], 15, 512) ?>;
    var userGrowthLabels = <?php echo json_encode($user_growth_data['labels'], 15, 512) ?>;
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
    <?php if (isset($component)) { $__componentOriginal360d002b1b676b6f84d43220f22129e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal360d002b1b676b6f84d43220f22129e2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumbs','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal360d002b1b676b6f84d43220f22129e2)): ?>
<?php $attributes = $__attributesOriginal360d002b1b676b6f84d43220f22129e2; ?>
<?php unset($__attributesOriginal360d002b1b676b6f84d43220f22129e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal360d002b1b676b6f84d43220f22129e2)): ?>
<?php $component = $__componentOriginal360d002b1b676b6f84d43220f22129e2; ?>
<?php unset($__componentOriginal360d002b1b676b6f84d43220f22129e2); ?>
<?php endif; ?>

    <?php echo ld_apply_filters('dashboard_after_breadcrumbs', ''); ?>


    <div class="grid grid-cols-12 gap-4 md:gap-6">
        <div class="col-span-12 space-y-6">
            <div class="grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-4 md:gap-6">
                <?php echo ld_apply_filters('dashboard_cards_before_users', ''); ?>

                <?php echo $__env->make('backend.pages.dashboard.partials.card', [
                "icon" => 'lucide:users',
                'icon_bg' => '#635BFF',
                'label' => __('Candidates'),
                'value' => $total_candidate,
                'class' => 'bg-white',
                'url' => route('admin.headhunters.candidates.index'),
                'enable_full_div_click' => true,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo ld_apply_filters('dashboard_cards_after_users', ''); ?>

                <?php echo $__env->make('backend.pages.dashboard.partials.card', [
                'icon' => 'lucide:building-2',
                'icon_bg' => '#00D7FF',
                'label' => __('Companies'),
                'value' => $total_company,
                'class' => 'bg-white',
                'url' => route('admin.headhunters.companies.index'),
                'enable_full_div_click' => true,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo ld_apply_filters('dashboard_cards_after_roles', ''); ?>

                <?php echo $__env->make('backend.pages.dashboard.partials.card', [
                'icon' => 'lucide:briefcase-business',
                'icon_bg' => '#FF4D96',
                'label' => __('Jobs'),
                'value' => $total_job,
                'class' => 'bg-white',
                'url' => route('admin.headhunters.jobs.index'),
                'enable_full_div_click' => true,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo ld_apply_filters('dashboard_cards_after_permissions', ''); ?>

                <?php echo $__env->make('backend.pages.dashboard.partials.card', [
                'icon' => 'lucide:file-text',
                'icon_bg' => '#22C55E',
                'label' => __('Applications'),
                'value' => $total_application,
                'class' => 'bg-white',
                'url' => route('admin.headhunters.applications.index'),
                'enable_full_div_click' => true,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo ld_apply_filters('dashboard_cards_after_translations', ''); ?>

            </div>
        </div>
    </div>

    <?php echo ld_apply_filters('dashboard_cards_after', ''); ?>


    <div class="mt-6">
        <div class="grid grid-cols-12 gap-4 md:gap-6">
            <div class="col-span-12">
                <div class="grid grid-cols-12 gap-4 md:gap-6">
                    <div class="col-span-12 md:col-span-8">
                        
                    </div>
                    <div class="col-span-12 md:col-span-4">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- <div class="mt-6">
            <div class="grid grid-cols-12 gap-4 md:gap-6">
                <div class="col-span-12">
                    <div class="grid grid-cols-12 gap-4 md:gap-6">
                        <?php echo $__env->make('backend.pages.dashboard.partials.post-chart', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>
        </div> -->

    <?php echo ld_apply_filters('dashboard_after', ''); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\gvanandita-dashboard\resources\views/backend/pages/dashboard/index.blade.php ENDPATH**/ ?>