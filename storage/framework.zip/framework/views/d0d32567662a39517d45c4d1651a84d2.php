

<?php $__env->startSection('title'); ?>
<?php echo e(__($breadcrumbs['title'])); ?> | <?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>

<div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
    <?php if (isset($component)) { $__componentOriginal360d002b1b676b6f84d43220f22129e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal360d002b1b676b6f84d43220f22129e2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumbs','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal360d002b1b676b6f84d43220f22129e2)): ?>
<?php $attributes = $__attributesOriginal360d002b1b676b6f84d43220f22129e2; ?>
<?php unset($__attributesOriginal360d002b1b676b6f84d43220f22129e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal360d002b1b676b6f84d43220f22129e2)): ?>
<?php $component = $__componentOriginal360d002b1b676b6f84d43220f22129e2; ?>
<?php unset($__componentOriginal360d002b1b676b6f84d43220f22129e2); ?>
<?php endif; ?>

    <h1 class="text-2xl font-bold mb-6 text-gray-800 dark:text-white"><?php echo e(__('Application Details')); ?></h1>

    <div class="bg-white shadow rounded-lg p-6 dark:bg-gray-900">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-x-12 gap-y-6">
            
            <div>
                <div class="mb-4">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300"><?php echo e(__('Application Information')); ?></h3>
                    <hr class="mt-1 mb-2 border-gray-200 dark:border-gray-700">
                    <div class="space-y-2 text-sm">
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Job Title')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->jobListing)->job_title ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Status')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e($application->status); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Applied At')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->applied_at)->format('d M Y') ?? 'N/A'); ?></span>
                        </div>
                    </div>
                </div>

                
                <div class="mb-4">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300"><?php echo e(__('Candidate Information')); ?></h3>
                    <hr class="mt-1 mb-2 border-gray-200 dark:border-gray-700">
                    <div class="space-y-2 text-sm">
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Name')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->candidate)->first_name . ' ' . optional($application->candidate)->last_name ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Email')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->candidate)->email ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Phone')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->candidate)->phone_number ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Experience')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->candidate)->work_experience_years ?? 'N/A'); ?> years</span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Current Salary')); ?>:</span>
                            <span class="text-gray-900 dark:text-white">
                                <?php if(optional($application->candidate)->current_salary): ?>
                                Rp <?php echo e(number_format($application->candidate->current_salary)); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Expected Salary')); ?>:</span>
                            <span class="text-gray-900 dark:text-white">
                                <?php if(optional($application->candidate)->expected_salary): ?>
                                Rp <?php echo e(number_format($application->candidate->expected_salary)); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Willing to Relocate')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->candidate)->willing_to_relocate ? 'Yes' : 'No'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Profile Status')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->candidate)->is_profile_complete ? 'Complete' : 'Incomplete'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Resume')); ?>:</span>
                            <span>
                                <?php if(optional($application->candidate)->resume_path): ?>
                                <a href="<?php echo e(asset('storage/' . $application->candidate->resume_path)); ?>" target="_blank" class="text-blue-500 underline"><?php echo e(__('View Resume')); ?></a>
                                <?php else: ?>
                                <span class="text-gray-500"><?php echo e(__('Not uploaded')); ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            
            <div>
                
                <div class="mb-4">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300"><?php echo e(__('Job Details')); ?></h3>
                    <hr class="mt-1 mb-2 border-gray-200 dark:border-gray-700">
                    <div class="space-y-2 text-sm">
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Company')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->jobListing->company)->name ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Location Type')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->jobListing)->job_location_type ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Experience Level')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->jobListing)->experience_level ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Job Type')); ?>:</span>
                            <span class="text-gray-900 dark:text-white"><?php echo e(optional($application->jobListing)->job_type ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Salary')); ?>:</span>
                            <span class="text-gray-900 dark:text-white">
                                <?php echo e(optional($application->jobListing)->salary_currency ?? 'N/A'); ?> <?php echo e(number_format(optional($application->jobListing)->min_salary)); ?> - <?php echo e(number_format(optional($application->jobListing)->max_salary)); ?>

                            </span>
                        </div>
                        <div class="flex items-center">
                            <span class="font-medium text-gray-600 w-32 dark:text-gray-400"><?php echo e(__('Description')); ?>:</span>
                        </div>
                        <p class="mt-2 text-gray-900 dark:text-white prose dark:prose-invert">
                            <?php echo e(optional($application->jobListing)->description ?? 'N/A'); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div>
                
                <div class="mb-4">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300"><?php echo e(__('Update Status & Feedback')); ?></h3>
                    <hr class="mt-1 mb-2 border-gray-200 dark:border-gray-700">
                    <form action="<?php echo e(route('admin.headhunters.applications.update', $application->id)); ?>" method="POST" class="space-y-4">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="flex flex-col">
                            <label for="status" class="font-medium text-gray-600 dark:text-gray-400 mb-1"><?php echo e(__('New Status')); ?></label>
                            <select name="status" id="status" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50 dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                                <option value="applied" <?php echo e($application->status == 'applied' ? 'selected' : ''); ?>><?php echo e(__('Applied')); ?></option>
                                <option value="in_review" <?php echo e($application->status == 'in_review' ? 'selected' : ''); ?>><?php echo e(__('In Review')); ?></option>
                                <option value="interview" <?php echo e($application->status == 'interview' ? 'selected' : ''); ?>><?php echo e(__('Interview')); ?></option>
                                <option value="rejected" <?php echo e($application->status == 'rejected' ? 'selected' : ''); ?>><?php echo e(__('Rejected')); ?></option>
                                <option value="hired" <?php echo e($application->status == 'hired' ? 'selected' : ''); ?>><?php echo e(__('Hired')); ?></option>
                            </select>
                        </div>
                        <div class="flex flex-col">
                            <label for="feedback" class="font-medium text-gray-600 dark:text-gray-400 mb-1 mt-4"><?php echo e(__('Feedback')); ?></label>
                            <textarea name="feedback" id="feedback" rows="4" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50 dark:bg-gray-800 dark:border-gray-700 dark:text-white"><?php echo e($application->feedback ?? ''); ?></textarea>
                        </div>
                        <button type="submit" class="w-full px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                            <?php echo e(__('Save Changes')); ?>

                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\gvanandita-dashboard\resources\views/backend/pages/applications/show.blade.php ENDPATH**/ ?>