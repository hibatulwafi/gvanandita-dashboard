

<?php $__env->startSection('title'); ?>
<?php echo e(__($breadcrumbs['title'])); ?> | <?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6"
    x-data="{ selectedJobs: [], selectAll: false, bulkDeleteModalOpen: false }">

    <?php if (isset($component)) { $__componentOriginal360d002b1b676b6f84d43220f22129e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal360d002b1b676b6f84d43220f22129e2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumbs','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal360d002b1b676b6f84d43220f22129e2)): ?>
<?php $attributes = $__attributesOriginal360d002b1b676b6f84d43220f22129e2; ?>
<?php unset($__attributesOriginal360d002b1b676b6f84d43220f22129e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal360d002b1b676b6f84d43220f22129e2)): ?>
<?php $component = $__componentOriginal360d002b1b676b6f84d43220f22129e2; ?>
<?php unset($__componentOriginal360d002b1b676b6f84d43220f22129e2); ?>
<?php endif; ?>

    <div class="space-y-6">
        <div class="rounded-md border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
            <div class="px-5 py-4 sm:px-6 sm:py-5 flex flex-col md:flex-row justify-between items-center gap-3">

                
                <?php echo $__env->make('backend.partials.search-form', [
                'placeholder' => __('Search by job title or company'),
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="flex items-center gap-3">
                    
                    <div class="relative" x-show="selectedJobs.length > 0" x-data="{ open: false }">
                        <button @click="open = !open" class="btn-secondary flex items-center gap-2 text-sm">
                            <iconify-icon icon="lucide:more-vertical"></iconify-icon>
                            <span><?php echo e(__('Bulk Actions')); ?> (<span x-text="selectedJobs.length"></span>)</span>
                            <iconify-icon icon="lucide:chevron-down"></iconify-icon>
                        </button>
                        <div x-show="open" @click.outside="open = false" x-transition
                            class="absolute right-0 mt-2 top-10 w-48 rounded-md shadow bg-white dark:bg-gray-700 z-10 p-2">
                            <ul>
                                <li class="cursor-pointer flex items-center gap-1 text-sm text-red-600 dark:text-red-500 hover:bg-red-50 px-2 py-1.5 rounded"
                                    @click="open = false; bulkDeleteModalOpen = true">
                                    <iconify-icon icon="lucide:trash"></iconify-icon> <?php echo e(__('Delete Selected')); ?>

                                </li>
                            </ul>
                        </div>
                    </div>

                    
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open" class="btn-secondary flex items-center gap-2 text-sm">
                            <iconify-icon icon="lucide:filter"></iconify-icon>
                            <span><?php echo e(__('Status')); ?></span>
                            <?php if(request('is_open')): ?>
                            <span class="px-2 py-0.5 text-xs bg-green-100 text-green-800 rounded-full">
                                <?php echo e(request('is_open') ? __('Open') : __('Closed')); ?>

                            </span>
                            <?php endif; ?>
                            <iconify-icon icon="lucide:chevron-down"></iconify-icon>
                        </button>
                        <div x-show="open" @click.outside="open = false" x-transition
                            class="absolute right-0 mt-2 top-10 w-48 rounded-md shadow bg-white dark:bg-gray-700 z-10 p-2">
                            <ul>
                                <li class="cursor-pointer text-sm px-2 py-1.5 rounded <?php echo e(!request('is_open') ? 'bg-gray-200' : ''); ?>"
                                    @click="window.location.href='<?php echo e(route('admin.headhunters.jobs.index', array_merge(request()->except('is_open')))); ?>'">
                                    <?php echo e(__('All')); ?>

                                </li>
                                <li class="cursor-pointer text-sm px-2 py-1.5 rounded <?php echo e(request('is_open') == 1 ? 'bg-gray-200' : ''); ?>"
                                    @click="window.location.href='<?php echo e(route('admin.headhunters.jobs.index', array_merge(request()->all(), ['is_open' => 1]))); ?>'">
                                    <?php echo e(__('Open')); ?>

                                </li>
                                <li class="cursor-pointer text-sm px-2 py-1.5 rounded <?php echo e(request('is_open') == 0 ? 'bg-gray-200' : ''); ?>"
                                    @click="window.location.href='<?php echo e(route('admin.headhunters.jobs.index', array_merge(request()->all(), ['is_open' => 0]))); ?>'">
                                    <?php echo e(__('Closed')); ?>

                                </li>
                            </ul>
                        </div>
                    </div>

                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('headhunters.jobs.create')): ?>
                    <a href="<?php echo e(route('admin.headhunters.jobs.create')); ?>" class="btn-primary flex items-center gap-2">
                        <iconify-icon icon="feather:plus" height="16"></iconify-icon>
                        <?php echo e(__('New Job')); ?>

                    </a>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="table-responsive">
                <table id="dataTable" class="table min-w-full">
                    <thead class="table-thead">
                        <tr class="table-tr">
                            <th width="3%" class="table-thead-th">
                                <input type="checkbox"
                                    class="form-checkbox h-4 w-4 text-primary border-gray-300 rounded"
                                    x-model="selectAll"
                                    @click="
                                        selectAll = !selectAll;
                                        selectedJobs = selectAll ? 
                                            [...document.querySelectorAll('.job-checkbox')].map(cb => cb.value) : [];
                                    ">
                            </th>
                            <th class="table-thead-th"><?php echo e(__('Job Title')); ?></th>
                            <th class="table-thead-th"><?php echo e(__('Company')); ?></th>
                            <th class="table-thead-th"><?php echo e(__('Category')); ?></th>
                            <th class="table-thead-th"><?php echo e(__('Location')); ?></th>
                            <th class="table-thead-th"><?php echo e(__('Status')); ?></th>
                            <th class="table-thead-th"><?php echo e(__('Featured')); ?></th>
                            <th class="table-thead-th"><?php echo e(__('Expires')); ?></th>
                            <th class="table-thead-th table-thead-th-last"><?php echo e(__('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($loop->index + 1 != count($jobs) ? 'table-tr' : ''); ?>">
                            <td class="table-td table-td-checkbox">
                                <input type="checkbox"
                                    value="<?php echo e($job->id); ?>"
                                    class="job-checkbox form-checkbox h-4 w-4 text-primary border-gray-300 rounded"
                                    x-model="selectedJobs">
                            </td>
                            <td class="table-td"><?php echo e($job->job_title); ?></td>
                            <td class="table-td"><?php echo e($job->company?->company_name ?? '-'); ?></td>
                            <td class="table-td"><?php echo e($job->category?->name ?? '-'); ?></td>
                            <td class="table-td"><?php echo e($job->city); ?>, <?php echo e($job->country); ?></td>
                            <td class="table-td">
                                <span class="badge <?php echo e($job->is_open ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                    <?php echo e($job->is_open ? __('Open') : __('Closed')); ?>

                                </span>
                            </td>
                            <td class="table-td">
                                <span class="badge <?php echo e($job->is_featured ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'); ?>">
                                    <?php echo e($job->is_featured ? __('Featured') : __('Normal')); ?>

                                </span>
                            </td>
                            <td class="table-td"><?php echo e($job->expires_at?->format('M d, Y') ?? '-'); ?></td>
                            <td class="table-td flex justify-center">
                                <?php if (isset($component)) { $__componentOriginalf71400415f89279b5d7a5bbf563c89d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf71400415f89279b5d7a5bbf563c89d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.action-buttons','data' => ['label' => __('Actions'),'showLabel' => false,'align' => 'right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.action-buttons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Actions')),'show-label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'align' => 'right']); ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('headhunters.jobs.edit')): ?>
                                    <?php if (isset($component)) { $__componentOriginald560e04bcb617ec3f965b99513409ac6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald560e04bcb617ec3f965b99513409ac6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.action-item','data' => ['href' => route('admin.headhunters.jobs.edit', $job->id),'icon' => 'pencil','label' => __('Edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.action-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.headhunters.jobs.edit', $job->id)),'icon' => 'pencil','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Edit'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald560e04bcb617ec3f965b99513409ac6)): ?>
<?php $attributes = $__attributesOriginald560e04bcb617ec3f965b99513409ac6; ?>
<?php unset($__attributesOriginald560e04bcb617ec3f965b99513409ac6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald560e04bcb617ec3f965b99513409ac6)): ?>
<?php $component = $__componentOriginald560e04bcb617ec3f965b99513409ac6; ?>
<?php unset($__componentOriginald560e04bcb617ec3f965b99513409ac6); ?>
<?php endif; ?>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('headhunters.jobs.view')): ?>
                                    <?php if (isset($component)) { $__componentOriginald560e04bcb617ec3f965b99513409ac6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald560e04bcb617ec3f965b99513409ac6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.action-item','data' => ['href' => route('admin.headhunters.jobs.show', $job->id),'icon' => 'eye','label' => __('View')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.action-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.headhunters.jobs.show', $job->id)),'icon' => 'eye','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('View'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald560e04bcb617ec3f965b99513409ac6)): ?>
<?php $attributes = $__attributesOriginald560e04bcb617ec3f965b99513409ac6; ?>
<?php unset($__attributesOriginald560e04bcb617ec3f965b99513409ac6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald560e04bcb617ec3f965b99513409ac6)): ?>
<?php $component = $__componentOriginald560e04bcb617ec3f965b99513409ac6; ?>
<?php unset($__componentOriginald560e04bcb617ec3f965b99513409ac6); ?>
<?php endif; ?>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('headhunters.jobs.delete')): ?>
                                    <div x-data="{ deleteModalOpen: false }">
                                        <?php if (isset($component)) { $__componentOriginald560e04bcb617ec3f965b99513409ac6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald560e04bcb617ec3f965b99513409ac6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.action-item','data' => ['type' => 'modal-trigger','modalTarget' => 'deleteModalOpen','icon' => 'trash','label' => __('Delete'),'class' => 'text-red-600 dark:text-red-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.action-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'modal-trigger','modal-target' => 'deleteModalOpen','icon' => 'trash','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Delete')),'class' => 'text-red-600 dark:text-red-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald560e04bcb617ec3f965b99513409ac6)): ?>
<?php $attributes = $__attributesOriginald560e04bcb617ec3f965b99513409ac6; ?>
<?php unset($__attributesOriginald560e04bcb617ec3f965b99513409ac6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald560e04bcb617ec3f965b99513409ac6)): ?>
<?php $component = $__componentOriginald560e04bcb617ec3f965b99513409ac6; ?>
<?php unset($__componentOriginald560e04bcb617ec3f965b99513409ac6); ?>
<?php endif; ?>

                                        <?php if (isset($component)) { $__componentOriginalca6d1ceba306f01b7889f217adc4dd4a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca6d1ceba306f01b7889f217adc4dd4a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modals.confirm-delete','data' => ['id' => 'delete-modal-'.e($job->id).'','title' => ''.e(__('Delete Job')).'','content' => ''.e(__('Are you sure you want to delete this job?')).'','formId' => 'delete-form-'.e($job->id).'','formAction' => ''.e(route('admin.headhunters.jobs.destroy', $job->id)).'','modalTrigger' => 'deleteModalOpen','cancelButtonText' => ''.e(__('No, cancel')).'','confirmButtonText' => ''.e(__('Yes, Confirm')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.confirm-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'delete-modal-'.e($job->id).'','title' => ''.e(__('Delete Job')).'','content' => ''.e(__('Are you sure you want to delete this job?')).'','formId' => 'delete-form-'.e($job->id).'','formAction' => ''.e(route('admin.headhunters.jobs.destroy', $job->id)).'','modalTrigger' => 'deleteModalOpen','cancelButtonText' => ''.e(__('No, cancel')).'','confirmButtonText' => ''.e(__('Yes, Confirm')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca6d1ceba306f01b7889f217adc4dd4a)): ?>
<?php $attributes = $__attributesOriginalca6d1ceba306f01b7889f217adc4dd4a; ?>
<?php unset($__attributesOriginalca6d1ceba306f01b7889f217adc4dd4a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca6d1ceba306f01b7889f217adc4dd4a)): ?>
<?php $component = $__componentOriginalca6d1ceba306f01b7889f217adc4dd4a; ?>
<?php unset($__componentOriginalca6d1ceba306f01b7889f217adc4dd4a); ?>
<?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf71400415f89279b5d7a5bbf563c89d0)): ?>
<?php $attributes = $__attributesOriginalf71400415f89279b5d7a5bbf563c89d0; ?>
<?php unset($__attributesOriginalf71400415f89279b5d7a5bbf563c89d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf71400415f89279b5d7a5bbf563c89d0)): ?>
<?php $component = $__componentOriginalf71400415f89279b5d7a5bbf563c89d0; ?>
<?php unset($__componentOriginalf71400415f89279b5d7a5bbf563c89d0); ?>
<?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="table-tr">
                            <td colspan="9" class="table-td text-center">
                                <span class="text-gray-500 dark:text-gray-300"><?php echo e(__('No jobs found.')); ?></span>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="my-4 px-4 sm:px-6">
                    <?php echo e($jobs->links()); ?>

                </div>
            </div>
        </div>
    </div>

    
    <div x-cloak x-show="bulkDeleteModalOpen" class="fixed inset-0 flex items-center justify-center bg-black/20 z-50">
        <div class="bg-white rounded shadow-md p-6 w-full max-w-md">
            <h2 class="text-lg font-bold"><?php echo e(__('Delete Selected Jobs')); ?></h2>
            <p class="text-gray-600"><?php echo e(__('Are you sure you want to delete the selected jobs? This action cannot be undone.')); ?></p>

            <form id="bulk-delete-form" action="<?php echo e(route('admin.headhunters.jobs.bulk-delete')); ?>" method="POST" class="mt-4 flex justify-end gap-3">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <template x-for="id in selectedJobs" :key="id">
                    <input type="hidden" name="ids[]" :value="id">
                </template>
                <button type="button" @click="bulkDeleteModalOpen = false" class="btn-secondary"><?php echo e(__('Cancel')); ?></button>
                <button type="submit" class="btn-danger"><?php echo e(__('Delete')); ?></button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\gvanandita-dashboard\resources\views/backend/pages/jobs/index.blade.php ENDPATH**/ ?>