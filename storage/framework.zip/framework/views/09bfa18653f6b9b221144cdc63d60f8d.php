<?php
    /** @var \App\Services\MenuService\AdminMenuItem $item */
?>

<?php if(isset($item->htmlData)): ?>
    <div class="menu-item-html" style="<?php echo $item->itemStyles; ?>">
        <?php echo $item->htmlData; ?>

    </div>
<?php elseif(!empty($item->children)): ?>
    <?php
        $submenuId = $item->id ?? \Str::slug($item->label) . '-submenu';
        $isActive = $item->active ? 'menu-item-active' : '';
        $showSubmenu = app(\App\Services\MenuService\AdminMenuService::class)->shouldExpandSubmenu($item);
        $rotateClass = $showSubmenu ? 'rotate-180' : '';
    ?>

    <li class="menu-item-<?php echo e($item->id); ?>" style="<?php echo $item->itemStyles; ?>">
        <button :style="`color: ${textColor}`" class="menu-item group w-full text-left <?php echo e($isActive); ?>" type="button" onclick="this.nextElementSibling.classList.toggle('hidden'); this.querySelector('.menu-item-arrow').classList.toggle('rotate-180')">
            <?php if(!empty($item->icon)): ?>
                <iconify-icon icon="<?php echo e($item->icon); ?>" class="menu-item-icon" width="18" height="18"></iconify-icon>
            <?php elseif(!empty($item->iconClass)): ?>
                <iconify-icon icon="lucide:circle" class="menu-item-icon" width="18" height="18"></iconify-icon>
            <?php endif; ?>
            <span class="menu-item-text"><?php echo $item->label; ?></span>
            <iconify-icon icon="lucide:chevron-down" class="menu-item-arrow transition-transform duration-300 <?php echo e($rotateClass); ?> w-4 h-4"></iconify-icon>
        </button>
        <ul id="<?php echo e($submenuId); ?>" class="submenu space-y-1 mt-1 overflow-hidden <?php echo e($showSubmenu ? '' : 'hidden'); ?>">
            <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('backend.layouts.partials.menu-item', ['item' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
<?php else: ?>
    <?php
        $isActive = $item->active ? 'menu-item-active' : 'menu-item-inactive';
        $target = !empty($item->target) ? ' target="' . e($item->target) . '"' : '';
    ?>

    <li class="menu-item-<?php echo e($item->id); ?>" style="<?php echo $item->itemStyles; ?>">
        <a :style="`color: ${textColor}`" href="<?php echo e($item->route ?? '#'); ?>" class="menu-item group <?php echo e($isActive); ?>" <?php echo $target; ?>>
            <?php if(!empty($item->icon)): ?>
                <iconify-icon icon="<?php echo e($item->icon); ?>" class="menu-item-icon" width="18" height="18"></iconify-icon>
            <?php elseif(!empty($item->iconClass)): ?>
                <iconify-icon icon="lucide:circle" class="menu-item-icon" width="18" height="18"></iconify-icon>
            <?php endif; ?>
            <span class="menu-item-text"><?php echo $item->label; ?></span>
        </a>
    </li>
<?php endif; ?>

<?php if(isset($item->id)): ?>
    <?php echo ld_apply_filters('sidebar_menu_item_after_' . strtolower($item->id), ''); ?>

<?php endif; ?>
<?php /**PATH D:\project\gvanandita-dashboard\resources\views/backend/layouts/partials/menu-item.blade.php ENDPATH**/ ?>