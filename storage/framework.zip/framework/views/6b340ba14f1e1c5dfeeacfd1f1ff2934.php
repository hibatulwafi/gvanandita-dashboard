<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'submitLabel' => __('Save'),
    'showSubmit' => true,
    'cancelLabel' => __('Cancel'),
    'cancelUrl' => null,
    'id' => null,
    'showIcon' => false,
    'classNames' => [
        'wrapper' => 'flex justify-start gap-3',
        'primary' => 'btn-primary',
        'cancel' => 'btn-default',
    ],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'submitLabel' => __('Save'),
    'showSubmit' => true,
    'cancelLabel' => __('Cancel'),
    'cancelUrl' => null,
    'id' => null,
    'showIcon' => false,
    'classNames' => [
        'wrapper' => 'flex justify-start gap-3',
        'primary' => 'btn-primary',
        'cancel' => 'btn-default',
    ],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="<?php echo e($classNames['wrapper'] ?? 'mt-6 flex justify-start gap-4'); ?>">
    <?php if($showSubmit): ?>
        <button type="submit" <?php if(!empty($id)): ?> id="<?php echo e($id); ?>" <?php endif; ?>
            class="<?php echo e($classNames['primary'] ?? 'btn-primary'); ?>">
            <?php if($showIcon): ?>
                <iconify-icon icon="lucide:check-circle" class="mr-2"></iconify-icon>
            <?php endif; ?>

            <?php if(!empty($submitLabel)): ?>
                <?php echo e($submitLabel); ?>

            <?php endif; ?>

            <?php if(empty($submitLabel) && $showIcon): ?>
                <?php echo e(__('Save')); ?>

            <?php endif; ?>
        </button>
    <?php endif; ?>

    <?php if(!empty($cancelLabel) && !empty($cancelUrl)): ?>
        <a href="<?php echo e($cancelUrl); ?>" class="<?php echo e($classNames['cancel'] ?? 'btn-default'); ?>">
            <?php if($showIcon): ?>
                <iconify-icon icon="lucide:x-circle" class="mr-2"></iconify-icon>
            <?php endif; ?>

            <?php echo e($cancelLabel); ?>

        </a>
    <?php endif; ?>
</div>
<?php /**PATH D:\project\gvanandita-dashboard\resources\views/components/buttons/submit-buttons.blade.php ENDPATH**/ ?>