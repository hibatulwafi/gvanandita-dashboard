<?php $__env->startSection('title'); ?>
    <?php echo e(__('Sign In')); ?> | <?php echo e(config('app.name')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
<div>
    <div class="mb-5 sm:mb-8">
      <h1 class="mb-2 font-semibold text-gray-700 text-title-sm dark:text-white/90 sm:text-title-md">
        <?php echo e(__('Sign In')); ?>

      </h1>
      <p class="text-sm text-gray-500 dark:text-gray-300">
        <?php echo e(__('Enter your email and password to sign in!')); ?>

      </p>
    </div>
    <div>
      <form action="<?php echo e(route('admin.login.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="space-y-5">
          <?php if (isset($component)) { $__componentOriginala357015bb12b9e55fb70db16bfbde37b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala357015bb12b9e55fb70db16bfbde37b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messages','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala357015bb12b9e55fb70db16bfbde37b)): ?>
<?php $attributes = $__attributesOriginala357015bb12b9e55fb70db16bfbde37b; ?>
<?php unset($__attributesOriginala357015bb12b9e55fb70db16bfbde37b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala357015bb12b9e55fb70db16bfbde37b)): ?>
<?php $component = $__componentOriginala357015bb12b9e55fb70db16bfbde37b; ?>
<?php unset($__componentOriginala357015bb12b9e55fb70db16bfbde37b); ?>
<?php endif; ?>

          <div>
            <label class="form-label" for="email"><?php echo e(__('Email')); ?></label>
            <input
              autofocus
              type="text"
              id="email"
              name="email"
              autocomplete="username"
              placeholder="<?php echo e(__('Enter your email')); ?>"
              class="form-control"
              value="<?php echo e(old('email') ?? config('app.demo_mode', false) ? 'superadmin@example.com' : ''); ?>"
              required
            />
          </div>

          <?php if (isset($component)) { $__componentOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.password','data' => ['name' => 'password','label' => ''.e(__('Password')).'','placeholder' => ''.e(__('Enter your password')).'','value' => ''.e((config('app.demo_mode', false) ? '12345678' : '')).'','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('inputs.password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password','label' => ''.e(__('Password')).'','placeholder' => ''.e(__('Enter your password')).'','value' => ''.e((config('app.demo_mode', false) ? '12345678' : '')).'','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9)): ?>
<?php $attributes = $__attributesOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9; ?>
<?php unset($__attributesOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9)): ?>
<?php $component = $__componentOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9; ?>
<?php unset($__componentOriginalc2ebe5a42e860f2e11b7caba8b7e3cb9); ?>
<?php endif; ?>

          <div class="flex items-center justify-between">
            <label for="remember" class="flex items-center justify-center gap-2 text-sm font-medium has-checked:text-gray-900 dark:has-checked:text-white has-disabled:cursor-not-allowed">
                <span class="relative flex items-center">
                    <input id="remember" name="remember" type="checkbox" class="before:content[''] peer relative size-4 appearance-none overflow-hidden rounded-sm border border-outline bg-surface-alt before:absolute before:inset-0 checked:border-primary checked:before:bg-primary focus:outline-2 focus:outline-offset-2 focus:outline-outline-strong checked:focus:outline-primary active:outline-offset-0 disabled:cursor-not-allowed dark:border-outline-dark dark:bg-surface-dark-alt dark:checked:border-primary-dark dark:checked:before:bg-primary-dark dark:focus:outline-outline-dark-strong dark:checked:focus:outline-primary-dark" checked/>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" stroke="currentColor" fill="none" stroke-width="4" class="pointer-events-none invisible absolute left-1/2 top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 text-white peer-checked:visible">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5"/>
                    </svg>
                </span>
                <span class="form-label mb-0"><?php echo e(__('Remember me')); ?></span>
            </label>
            <a href="<?php echo e(route('admin.password.request')); ?>" class="text-sm text-brand-500 hover:text-brand-600 dark:text-brand-400"><?php echo e(__('Forgot password?')); ?></a>
          </div>

          <?php if (isset($component)) { $__componentOriginalc8680908dbd82701772537a108fb92cd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8680908dbd82701772537a108fb92cd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.recaptcha','data' => ['page' => 'login']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('recaptcha'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'login']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8680908dbd82701772537a108fb92cd)): ?>
<?php $attributes = $__attributesOriginalc8680908dbd82701772537a108fb92cd; ?>
<?php unset($__attributesOriginalc8680908dbd82701772537a108fb92cd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8680908dbd82701772537a108fb92cd)): ?>
<?php $component = $__componentOriginalc8680908dbd82701772537a108fb92cd; ?>
<?php unset($__componentOriginalc8680908dbd82701772537a108fb92cd); ?>
<?php endif; ?>

          <div>
            <button type="submit" class="btn-primary w-full ">
              <?php echo e(__('Sign In')); ?>

              <iconify-icon icon="lucide:log-in" class="ml-2"></iconify-icon>
            </button>
          </div>
          <?php if(config('app.demo_mode', false)): ?>
          <div x-data="{ showDemoCredentials: false }" class="mt-4 border border-gray-200 dark:border-gray-700 rounded-md overflow-hidden">
            <button
              type="button"
              @click="showDemoCredentials = !showDemoCredentials"
              class="flex justify-between items-center w-full px-4 py-3 text-sm font-medium text-left text-brand-600 dark:text-brand-400 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              <span>
                <iconify-icon icon="lucide:info" class="mr-2"></iconify-icon>
                <?php echo e(__('Demo Credentials')); ?>

              </span>
              <iconify-icon :icon="showDemoCredentials ? 'lucide:chevron-up' : 'lucide:chevron-down'"></iconify-icon>
            </button>

            <div x-show="showDemoCredentials" x-transition class="px-4 py-3 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
              <div class="mb-3">
                <p class="text-sm text-gray-600 dark:text-gray-300"><?php echo e(__('Use these credentials to explore the demo:')); ?></p>
              </div>
              <div class="grid grid-cols-1 gap-2 mb-3 text-gray-500 dark:text-gray-300">
                <div class="flex items-center">
                  <span class="w-20 text-xs font-medium"><?php echo e(__('Email:')); ?></span>
                  <code class="px-2 py-1 text-xs font-mono bg-gray-100 dark:bg-gray-800 rounded">superadmin@example.com</code>
                </div>
                <div class="flex items-center">
                  <span class="w-20 text-xs font-medium"><?php echo e(__('Password:')); ?></span>
                  <code class="px-2 py-1 text-xs font-mono bg-gray-100 dark:bg-gray-800 rounded">12345678</code>
                </div>
              </div>
              <button
                type="button"
                id="fill-demo-credentials"
                class="!text-xs btn-default"
              >
                <?php echo e(__('Login Now')); ?>

                <iconify-icon icon="lucide:log-in" class="ml-1"></iconify-icon>
              </button>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php if(config('app.demo_mode', false)): ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.getElementById('fill-demo-credentials').addEventListener('click', function() {
              console.log('clicked');
                document.getElementById('email').value = 'superadmin@example.com';
                document.querySelector('input[name="password"]').value = '12345678';
                document.querySelector('form').submit();
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('backend.auth.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\gvanandita-dashboard\resources\views/backend/auth/login.blade.php ENDPATH**/ ?>